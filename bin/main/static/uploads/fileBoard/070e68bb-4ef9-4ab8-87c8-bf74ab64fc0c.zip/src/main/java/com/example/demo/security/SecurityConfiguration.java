package com.example.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
public class SecurityConfiguration {
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
		.authorizeHttpRequests()
			.antMatchers("/","/home").permitAll()  //인증없이 허용하겠다
			.anyRequest().authenticated()          //그 외 모든 리소스는 인증 필요 
			.and()
		.formLogin()
			.loginPage("/login")
			.permitAll()
			.and()
		.logout()
			.permitAll();
			
		return http.build();
	}
	
	@Bean
	public UserDetailsService userDetailsService() {
		UserDetails user=User.withDefaultPasswordEncoder()  //withDefaultPasswordEncoder deprecated 되었다
			.username("user")
			.password("password")
			.roles("USER")
			.build();
		return new InMemoryUserDetailsManager(user); //사용자 정보를 추가한다
	}
}


/*
 * http.formLogin() 
 * .loginPage("/login.html") // 사용자 정의 로그인 페이지
 * .defaultSuccessUrl("/home") // 로그인 성공 후 이동 페이지
 * .failureUrl("/login.html?error=true") // 로그인 실패 후 이동 페이지
 * .usernameParameter("username") // 아이디 파라미터명 설정 
 * .passwordParameter("password") // 패스워드 파라미터명 설정 
 * .loginProcessingUrl("/login") // 로그인 Form Action Url
 * .successHandler(loginSuccessHandler()) // 로그인 성공 후 핸들러
 * .failureHandler(loginFailureHandler()) // 로그인 실패 후 핸들러
 
 http.rememberMe()
	.rememberMeParameter(“remember”) // 기본 파라미터명은 remember-me
    .tokenValiditySeconds(3600) // Default 는 14일
    .alwaysRemember(true) // 리멤버 미 기능이 활성화되지 않아도 항상 실행
    .userDetailsService(userDetailsService)
 
 
 http.sessionManagement()
	.maximumSessions(1)                 // 최대 허용 가능 세션 수 , -1 : 무제한 로그인 세션 허용
    .maxSessionsPreventsLogin(true) // 동시 로그인 차단함,  false : 기존 세션 만료(default)
    .invalidSessionUrl("/invalid")       // 세션이 유효하지 않을 때 이동 할 페이지
    .expiredUrl("/expired ")  	        // 세션이 만료된 경우 이동 할 페이지
 */